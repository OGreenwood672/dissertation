use pyo3::prelude::*;
use numpy::{IntoPyArray, PyArray1};
use rayon::iter::{IndexedParallelIterator, IntoParallelRefIterator, IntoParallelRefMutIterator, ParallelIterator};
use rayon::slice::ParallelSlice;
use tokio::runtime::Runtime;
use serde_json::{self, Value};
use tokio::signal;
use tokio::sync::broadcast;
use tokio_util::sync::CancellationToken;
use crate::agent::{ToActions};
use crate::config::{load_config};
use crate::world::World;
use crate::websocket::websocket;
use tokio::task::JoinHandle;
use std::iter::repeat_with;

#[pyclass(skip_from_py_object)]
#[derive(Clone)]
pub struct SimConfig {
    headless: bool,

    #[pyo3(get)]
    n_agents: u32,

    #[pyo3(get)]
    n_worlds: u32,

}


#[pyclass]
pub struct Simulation {
    worlds: Vec<World>,
    bcast_tx: broadcast::Sender<String>,
    _server_handle: JoinHandle<()>,
    cancel_token: CancellationToken,
    #[expect(unused)]
    rt: Runtime,

    #[pyo3(get)]
    config: SimConfig
}

#[pymethods]
impl Simulation {
    #[new]
    pub fn new(config_path: String, worlds_parallised: i32) -> PyResult<Self> {

        let rt = Runtime::new()?;

        let config = load_config(&config_path).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Failed to load config: {}", e))
        })?;

        let is_headless = config.headless;
        if !is_headless {
            println!("Starting simulation with UI server...");
        } else {
            println!("Starting simulation without UI server...");
        }

        let (worlds, bcast_tx, _server_handle, cancel_token) = rt.block_on(async {
            let worlds = repeat_with(|| World::new(config.clone()))
                            .take(worlds_parallised as usize)
                            .collect();

            let (bcast_tx, _) = broadcast::channel::<String>(32);
            let cancel_token = CancellationToken::new();

            let server_handle = {
                let ws_filter = websocket(bcast_tx.clone());
                let cancel_clone = cancel_token.clone();
                tokio::spawn(async move {
                    warp::serve(ws_filter)
                    .bind(([127, 0, 0, 1], 3000)).await
                    .graceful(async move {
                        signal::ctrl_c().await.expect("failed to install Ctrl+C handler");
                        cancel_clone.cancel();
                    })
                    .run().await;
                })
            };

            PyResult::Ok((worlds, bcast_tx, server_handle, cancel_token))
        })?;

        Ok(Simulation {
            worlds,
            bcast_tx,
            _server_handle,
            cancel_token,
            rt,
            config: SimConfig {
                headless: is_headless,
                n_agents: config.agents.len() as u32,
                n_worlds: worlds_parallised as u32
            }
        })
    }

    pub fn parallel_step<'py>(
        &mut self,
        py: Python<'py>,
        flat_actions: Vec<i32>,
    ) -> PyResult<(Bound<'py, PyArray1<f32>>, Bound<'py, PyArray1<f32>>, Bound<'py, PyArray1<f32>>, Bound<'py, PyArray1<f32>>)> {
            
        let n_agents = self.worlds[0].get_number_of_agents();
        let n_worlds = self.worlds.len();
        
        if flat_actions.len() != n_worlds * n_agents {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid number of actions"));
        }

        let obs_size = self.worlds[0].get_agent_obs_size() as usize;
        let total_obs_len = n_worlds * n_agents * obs_size;
        let total_global_obs_len = n_worlds * self.worlds[0].get_global_obs_size() as usize;
        let total_rew_len = n_worlds * n_agents;

        let results: Vec<(Vec<f32>, Vec<f32>, Vec<f32>, Vec<f32>, Option<Value>)> = self.worlds.par_iter_mut()
            .enumerate()
            .zip(flat_actions.par_chunks(n_agents))
            .map(|((world_id, world), world_actions)| {

                let agent_actions = ToActions::to_actions(world_actions.to_vec());

                world.apply_actions(agent_actions);
                world.spread_rewards(0.5);
                
                let obs = world.get_agents_obs();
                let global_obs = world.get_global_obs();
                let rewards = world.get_agents_reward();
                let agent_targets = world.get_agents_targets();

                let mut flat_world_obs = Vec::with_capacity(obs.len() * (obs[0].len()));// + world_comms.len()));

                for agent_obs in obs {
                    flat_world_obs.extend_from_slice(&agent_obs);
                }

                let flat_agent_targets = agent_targets.concat();

                let json_state = if !self.config.headless { 
                    Some(serde_json::json!({ "world_id": world_id as f32, "world_state": world.get_state() }))
                } else { 
                    None
                };

                (flat_world_obs, global_obs, flat_agent_targets, rewards, json_state)
            })
            .collect();
            
        let mut all_obs = Vec::with_capacity(total_obs_len);
        let mut all_global_obs = Vec::with_capacity(total_global_obs_len);
        let mut all_rewards = Vec::with_capacity(total_rew_len);
        let mut all_targets = Vec::with_capacity(total_rew_len * 3);


        for (w_obs, w_global_obs, w_targets, w_rew, json_state) in results {
            all_obs.extend(w_obs);
            all_global_obs.extend(w_global_obs);
            all_rewards.extend(w_rew);
            all_targets.extend(w_targets);

            if let Some(state) = json_state {
                let state_string = serde_json::to_string(&state)
                        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("failed to serialize world state: {}", e)))?;
                let _ = self.bcast_tx.send(state_string);
            }
        }

        let obs_numpy: Bound<'py, PyArray1<f32>> = all_obs.into_pyarray(py);
        let global_obs_numpy: Bound<'py, PyArray1<f32>> = all_global_obs.into_pyarray(py);
        let rewards_numpy: Bound<'py, PyArray1<f32>> = all_rewards.into_pyarray(py);
        let targets_numpy: Bound<'py, PyArray1<f32>> = all_targets.into_pyarray(py);

        Ok((obs_numpy, global_obs_numpy, targets_numpy, rewards_numpy))

    }

    pub fn get_optimal_actions<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyArray1<i32>>> {

        let optimal_actions: Vec<i32> = self.worlds.iter().map(|world| {
            let optimal_actions = world.get_optimal_actions();
            optimal_actions.into_iter().map(|action| action as i32)
        }).flatten().collect();

        Ok(optimal_actions.into_pyarray(py))

    }

    pub fn get_targets<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyArray1<f32>>> {
        let targets: Vec<f32> = self.worlds.iter().map(|world| {
            world.get_agents_targets()
        }).flatten().flatten().collect();

        Ok(targets.into_pyarray(py))
    }


    pub fn shutdown(&self) -> PyResult<()> {
        println!("Shutting down simulation server...");
        self.cancel_token.cancel();
        Ok(())
    }

    pub fn reset(&mut self, world_id: i32) -> PyResult<()> {
        
        let world = &mut self.worlds[world_id as usize];

        world.reset_agents();
        world.reset_stations();

        Ok(())
    }

    pub fn get_number_of_agents(&self, world_id: i32) -> PyResult<usize> {
        let world = &self.worlds[world_id as usize];
        Ok(world.get_number_of_agents())
    }

    pub fn get_agent_action_count(&self, world_id: i32) -> PyResult<u32> {
        let world = &self.worlds[world_id as usize];
        Ok(world.get_agent_action_count())
    }

    pub fn get_agent_obs(&self, world_id: i32, agent_id: i32) -> PyResult<Vec<f32>> {
        let world = &self.worlds[world_id as usize];
        let obs = world.get_agent_obs(agent_id as usize);
        Ok(obs)
    }

    pub fn get_agent_external_obs_mask(&self, world_id: i32) -> PyResult<Vec<bool>> {
        let world = &self.worlds[world_id as usize];
        let obs_mask = world.get_agent_external_obs_mask();
        Ok(obs_mask)
    }

    pub fn get_agent_obs_mask(&self, world_id: i32) -> PyResult<Vec<bool>> {
        let world = &self.worlds[world_id as usize];
        let obs_mask = world.get_agent_obs_mask();
        Ok(obs_mask)
    }

    pub fn get_agent_obs_size(&self, world_id: i32) -> PyResult<u32> {
        let world = &self.worlds[world_id as usize];
        let obs_size = world.get_agent_obs_size();
        Ok(obs_size)
    }

    pub fn get_agent_reward(&self, world_id: i32, agent_id: i32) -> PyResult<f32> {
        let world = &self.worlds[world_id as usize];
        let obs = world.get_agent_reward(agent_id as usize);
        Ok(obs)
    }

    pub fn get_global_obs(&self, world_id: i32) -> PyResult<Vec<f32>> {
        let world = &self.worlds[world_id as usize];
        let obs = world.get_global_obs();
        Ok(obs)
    }

    pub fn get_all_global_obs(&self, py: Python<'_>) -> PyResult<Vec<f32>> {
        Python::detach(py, || {
            let results: Vec<f32> = self.worlds.par_iter()
                .flat_map(|world| world.get_global_obs())
                .collect();

            Ok(results)
        })
    }

    pub fn get_global_obs_size(&self, world_id: i32) -> PyResult<u32> {
        let world = &self.worlds[world_id as usize];
        let obs_size = world.get_global_obs_size();
        Ok(obs_size)
    }

}

#[cfg(test)]
mod tests {
    use super::*;
    use pyo3::exceptions::PyValueError;

    #[test]
    fn parallel_step_rejects_wrong_number_of_actions() {
        Python::initialize();
        Python::attach(|py| {
            let config_path = "../configs/simulation.yaml".to_string();
            let mut sim = Simulation::new(config_path, 2).unwrap();

            let n_agents = sim.get_number_of_agents(0).unwrap();
            let n_worlds = sim.config.n_worlds as usize;

            let flat_actions = vec![0; n_agents * n_worlds - 1];

            let err = sim.parallel_step(py, flat_actions).unwrap_err();

            assert!(err.is_instance_of::<PyValueError>(py));
            assert_eq!(err.to_string(), "ValueError: Invalid number of actions");
        });
    }
}